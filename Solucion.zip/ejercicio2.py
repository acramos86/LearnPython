# Calcular el perímetro y área de un rectángulo dada su base y su altura.

base=float(input("Introduce la base:"))
altura=float(input("Introduce la altura:"))
perimetro = 2 * base * altura
area = base * altura
print("El perimetro es", perimetro, "y el area es", area)