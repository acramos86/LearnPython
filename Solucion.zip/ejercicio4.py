# Dados dos números, mostrar la suma, resta, división y multiplicación de ambos.

num1 = float(input("Introduce el número 1:"))
num2 = float(input("Introduce el número 2:"))
print("La suma es", num1+num2)
print("La resta es", num1-num2)
print("La multiplicación es", num1*num2)
print("La división es", num1/num2)
