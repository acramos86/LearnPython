# Pide al usuario dos números y muestra la "distancia" entre ellos 
# (el valor absoluto de su diferencia, de modo que el resultado sea siempre positivo).

num1 = int(input("Dime el número 1:"))
num2 = int(input("Dime el número 2:"))
print("Distancia:", abs(num1 - num2))