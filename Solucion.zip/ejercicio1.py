# Escribir un programa que pregunte al usuario su nombre, y luego lo salude.

nombre=input("Dime tu nombre:")
print("Hola",nombre)